class Movie:
    def __init__(self, id, name, rating):
        self.id = id
        self.name = name
        self.rating = rating
    def display(self):
        print(f"Movie Id = {self.id}, Name = {self.name}, Rating = {self.rating}")
m1 = Movie(101, "3 Idiots", 8.8)
m2 = Movie(102, "Fidaa", 9.9)
m1.display()
m2.display()