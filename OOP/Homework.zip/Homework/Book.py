class Book:
    def __init__(self, id, name, price):
        self.id = id
        self.name = name
        self.price = price
    def display(self):
        print(f"Book Id = {self.id}, Name = {self.name}, Price = {self.price}")
b1 = Book(101, "Python", 550)
b2 = Book(102, "Java", 600)
b1.display()
b2.display()